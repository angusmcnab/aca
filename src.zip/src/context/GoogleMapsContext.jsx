import { createContext, useContext } from 'react';
import { useJsApiLoader } from '@react-google-maps/api';

const GoogleMapsContext = createContext(null);
const libraries = ['places'];

export function GoogleMapsProvider({ children }) {
  const apiKey = import.meta.env.VITE_Maps_API_KEY || '';
  if (!apiKey) console.error('Missing VITE_Maps_API_KEY in .env');
  const { isLoaded, loadError } = useJsApiLoader({
    id: 'google-map-script',
    googleMapsApiKey: apiKey,
    libraries,
  });
  return (
    <GoogleMapsContext.Provider value={{ isLoaded, loadError }}>
      {children}
    </GoogleMapsContext.Provider>
  );
}

export function useGoogleMaps() {
  const context = useContext(GoogleMapsContext);
  if (!context) throw new Error('useGoogleMaps must be within GoogleMapsProvider');
  return context;
}