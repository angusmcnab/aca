import { useState, useEffect, useRef } from "react";
import { useGoogleMaps } from "../context/GoogleMapsContext";
import { toast } from "react-hot-toast";

export default function LocationAutocomplete({ onSelectAddress, initialValue = '' }) {
  const { isLoaded, loadError } = useGoogleMaps();
  const [inputValue, setInputValue] = useState(initialValue);
  const [suggestions, setSuggestions] = useState([]);
  const autocompleteService = useRef(null);

  useEffect(() => {
    if (isLoaded && !loadError && window.google) {
      autocompleteService.current = new window.google.maps.places.AutocompleteService();
    }
  }, [isLoaded, loadError]);

  useEffect(() => {
    setInputValue(initialValue || '');
  }, [initialValue]);

  useEffect(() => {
    if (autocompleteService.current && inputValue) {
      autocompleteService.current.getPlacePredictions(
        { input: inputValue },
        (predictions, status) => {
          if (status === window.google.maps.places.PlacesServiceStatus.OK && predictions) {
            setSuggestions(predictions);
          } else {
            setSuggestions([]);
          }
        }
      );
    } else {
      setSuggestions([]);
    }
  }, [inputValue, isLoaded]);

  useEffect(() => {
      if(loadError) {
          toast.error('Failed to load Google Maps. Please check API key.', { id: 'maps-error' });
      }
  }, [loadError]);


  if (loadError) {
    return <input className="mt-1 w-full p-2 border rounded bg-red-100 text-red-700" disabled value="Map service failed" />;
  }
  
  if (!isLoaded) {
    return (
      <div className="mt-1 w-full p-2 border rounded bg-gray-100 text-gray-500 flex items-center">
        <svg className="animate-spin h-5 w-5 mr-2" viewBox="0 0 24 24">
            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
        </svg>
        Loading map...
      </div>
    );
  }

  const handleInput = (e) => setInputValue(e.target.value);
  const handleSelect = (suggestion) => {
    setInputValue(suggestion.description);
    onSelectAddress(suggestion.description);
    setSuggestions([]);
  };

  return (
    <div className="relative">
      <input id="job-location" className="mt-1 w-full p-2 border rounded" value={inputValue} onChange={handleInput} placeholder="Start typing an address..."/>
      {suggestions.length > 0 && (
        <ul className="absolute z-10 w-full bg-white border border-gray-300 rounded-b-md shadow-lg mt-1">
          {suggestions.map((suggestion) => (
            <li key={suggestion.place_id} onClick={() => handleSelect(suggestion)} className="p-2 hover:bg-gray-100 cursor-pointer">
              {suggestion.description}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}